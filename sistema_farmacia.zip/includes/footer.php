<footer class="footer">
    <div class="footer-container">
        <p>&copy; <?php echo date('Y'); ?> PharmacyDB - Sistema de Gestión de Farmacias</p>
        <p class="db-info">
            <i class="fas fa-database"></i> PostgreSQL | 
            <i class="fas fa-code"></i> PHP | 
            <i class="fas fa-server"></i> Apache
        </p>
    </div>
</footer>